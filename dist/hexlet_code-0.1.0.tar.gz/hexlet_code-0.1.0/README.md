### Hexlet tests and linter status:
[![Actions Status](https://github.com/Vaeriks/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Vaeriks/python-project-49/actions)